### Hi there 👋


I am Haseeb. An enthusiastic and passionate mobile application and web-developer with a firm hands on various programming areas. I possess the adequate experience to become a part of the software development stages such as requirement gathering, designing, development, deployment and testing. Using my more then 8+ years of experience, currently, I am working on trending technologies and so far I have made myself proficient in the following techs:

- JavaScript
- React.js / Next.js 🚀
- React Native 🚀
- Node.js (Express.js)
- SQL and NoSQL databases (MongoDB, etc)
- Firebase
- AWS Services

Attention to detail and acquiring optimum results enables me to deliver to the best of my abilities.

Have an interesting startup idea to discuss or want to get technical assistance in new or current projects? You can reach out to me on [twitter](https://twitter.com/Haseebrehmankhi) or [linkedin](https://www.linkedin.com/in/haseeb-ur-rehman/).

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=haseebrehmanpc&" alt="haseebrehmanpc" /></p>


<!--
**haseebrehmanpc/haseebrehmanpc** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
