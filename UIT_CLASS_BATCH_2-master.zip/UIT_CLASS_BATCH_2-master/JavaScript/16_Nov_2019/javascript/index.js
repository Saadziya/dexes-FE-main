// var text = 'Hello World.'

// text = 'Hello Pakistan'

// alert(text)
// alert()

var text1 = 'abc';

var text2 = 456;

alert(text1 - text2);


// var name = "Haseeb";

// alert("Hello, "+name);