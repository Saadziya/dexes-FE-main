import React from 'react';

import './Root.scss';

const Root: React.FC = () => (
  <div>Hello World...</div>
);

export default Root;
