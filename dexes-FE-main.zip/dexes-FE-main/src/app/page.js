"use client";

import MainPage from "@/component/mainPage";

const mainData = [];
export default function Home() {


  return (
    <MainPage />
  );
}
