<template>
    <v-container fluid>
        <v-layout row wrap>
            <v-flex xs12 class="text-xs-center" mt-5>
                <h1>Welcome to Two-Pager</h1>
                <h4>Select a view from top navigation bar</h4>
            </v-flex>
        </v-layout>
    </v-container>
</template>

<script>
export default {};
</script>
  