import Employee from "./Employee";

export {
    Employee,
}