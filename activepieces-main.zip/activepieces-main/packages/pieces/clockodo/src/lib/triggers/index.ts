import newEntryTrigger from './new-entry'
import newAbsenceEnquiryTrigger from "./new-absence-enquiry";

export default [
    newEntryTrigger,
    newAbsenceEnquiryTrigger
]
