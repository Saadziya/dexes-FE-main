import getAction from "./get-team";
import listAction from "./list-teams";

export default [
    getAction,
    listAction
]
