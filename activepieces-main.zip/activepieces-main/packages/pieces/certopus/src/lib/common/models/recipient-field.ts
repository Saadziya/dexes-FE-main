export interface RecipientField {
  key: string;
  label: string;
  type: string;
}
