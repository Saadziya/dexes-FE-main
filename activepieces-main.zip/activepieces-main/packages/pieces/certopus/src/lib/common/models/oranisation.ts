export interface Organisation {
  id: string;
  imageUrl: string;
  name: string;
  integrationAllowed: boolean;
}