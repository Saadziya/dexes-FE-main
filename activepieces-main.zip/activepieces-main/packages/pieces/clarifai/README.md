# pieces-clarifai

This library was generated with [Nx](https://nx.dev).

## Running lint

Run `nx lint pieces-clarifai` to execute the lint via [ESLint](https://eslint.org/).
