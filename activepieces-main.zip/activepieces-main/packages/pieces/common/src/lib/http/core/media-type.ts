export enum MediaType {
	APPLICATION_JSON = 'application/json',
}
