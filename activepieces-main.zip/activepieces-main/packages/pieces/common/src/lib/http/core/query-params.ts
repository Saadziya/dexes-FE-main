export type QueryParams = Record<string, string>;
