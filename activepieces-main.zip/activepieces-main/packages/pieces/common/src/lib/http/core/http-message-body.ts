export type HttpMessageBody = Record<string, any>;
