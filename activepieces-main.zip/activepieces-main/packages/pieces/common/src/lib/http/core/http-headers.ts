export type HttpHeaders = Record<string, string | string[] | undefined>;
