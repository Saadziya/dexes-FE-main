# pieces-common

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build pieces-common` to build the library.
