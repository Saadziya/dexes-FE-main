# pieces-cal-com

This library was generated with [Nx](https://nx.dev).

## Running lint

Run `nx lint pieces-cal-com` to execute the lint via [ESLint](https://eslint.org/).
