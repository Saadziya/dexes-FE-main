import { AppConnectionService } from './app-connection-service'

export const appConnectionService = new AppConnectionService()
