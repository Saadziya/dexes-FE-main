import { CreateStepRunRequestBody } from '@activepieces/shared'

export const CreateStepRunRequest = {
    schema: {
        body: CreateStepRunRequestBody,
    },
}
