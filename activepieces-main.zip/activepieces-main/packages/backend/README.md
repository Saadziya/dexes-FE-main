# Backend

## scripts

### Generate database migrations

```sh
npx nx db-migration backend -- --name migration-name
```
