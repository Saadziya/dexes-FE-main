# engine

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build engine` to build the library.

## Running unit tests

Run `nx test engine` to execute the unit tests via [Jest](https://jestjs.io).
