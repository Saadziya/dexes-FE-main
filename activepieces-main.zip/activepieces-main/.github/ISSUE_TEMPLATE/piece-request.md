---
name: Piece Request
about: Request new Action / Trigger
title: ''
labels: pieces
assignees: ''

---

**Describe your usecase.**
A clear and concise description how exactly you want to use the piece.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions you've considered.
